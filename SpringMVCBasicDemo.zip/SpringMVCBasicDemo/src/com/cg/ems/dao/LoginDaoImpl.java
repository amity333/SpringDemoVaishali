package com.cg.ems.dao;

import java.util.ArrayList;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.transaction.Transactional;

import org.springframework.stereotype.Component;

import com.cg.ems.dto.Login;
import com.cg.ems.dto.RegisterDto;

@Component
@Transactional
public class LoginDaoImpl implements LoginDao{

	
	@PersistenceContext
	EntityManager em;
	@Override
	public Login getUserById(String unm) {
		
	    System.out.println("in LoginDao setUserById");
	    Login user=em.find(Login.class, unm);
		return user;
	}
	@Override
	public RegisterDto addUserDetails(RegisterDto userDetails) {
		
		em.persist(userDetails);
		RegisterDto reg=em.find(RegisterDto.class, userDetails.getUname());
		return reg;
	}
	@Override
	public ArrayList<RegisterDto> getAllUserDetails() {
		
		String selectUserQry="SELECT reg FROM RegisterDto reg";
		
		return null;
	}
	@Override
	public Login addUser(Login user) {
		
		em.persist(user);
		Login uu=em.find(Login.class, user.getUserName());
		return uu;
	}

}
