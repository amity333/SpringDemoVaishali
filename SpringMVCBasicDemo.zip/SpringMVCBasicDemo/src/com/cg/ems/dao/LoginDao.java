package com.cg.ems.dao;

import java.util.ArrayList;

import com.cg.ems.dto.Login;
import com.cg.ems.dto.RegisterDto;

public interface LoginDao {

	public Login getUserById(String unm);
	public RegisterDto addUserDetails(RegisterDto userDetails);
	public Login addUser(Login user);
	public ArrayList<RegisterDto> getAllUserDetails();
	
}
